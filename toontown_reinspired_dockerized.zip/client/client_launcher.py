# Client launcher placeholder
print('Launching client...')